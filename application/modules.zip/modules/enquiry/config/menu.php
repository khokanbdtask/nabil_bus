<?php

// module name
$HmvcMenu["enquiry"] = array(
    //set icon
    "icon"           => "<i class='fa fa-question-circle-o'></i>", 
    
    //1st level menu name
    "enquiry" => array( 
        "controller" => "home",
        "method"     => "index",
        "permission" => "read"
    ), 

    // "setting" => array( 
    //     "controller" => "home",
    //     "method"     => "form",
    //     "permission" => "create"
    // ), 

  
);
   

 