DELETE FROM `language` WHERE `language`.`phrase` = 'tracking_list';
DELETE FROM `language` WHERE `language`.`phrase` = 'progress';
DELETE FROM `language` WHERE `language`.`phrase` = 'reached_points';
DELETE FROM `language` WHERE `language`.`phrase` = 'arrival_time';
DELETE FROM `language` WHERE `language`.`phrase` = 'tracking_route_id';
DELETE FROM `language` WHERE `language`.`phrase` = 'tracking_date';
DELETE FROM `language` WHERE `language`.`phrase` = 'tracking_fleet_id';
DELETE FROM `language` WHERE `language`.`phrase` = 'delete_tracking';
DELETE FROM `language` WHERE `language`.`phrase` = 'edit_tracking';
DELETE FROM `language` WHERE `language`.`phrase` = 'tracking';
DELETE FROM `language` WHERE `language`.`phrase` = 'add_tracking';

-- Above code is for deleting label's of the tracking

