<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>DigitalRainbow</title>

    <!-- Bootstrap -->
    <link href="<?php echo base_url('assets/css/bootstrap.min.css')?>" rel="stylesheet">
    <link href="<?php echo base_url('assets/css/style.css')?>" rel="stylesheet">
    <link href="<?php echo base_url('assets/css/bhojon.css')?>" rel="stylesheet">

    
</head>
<body onload="window.print()">
<!-- <body> -->
 

        <?php for($print = 1; $print<= $numberofprint; $print++) { ?>

               

            <div class="" style="width: 100%; margin-bottom: 40px; height:900px">

            
            <table class="table table-bordered" style="width: 100%; margin-bottom: 40px;">
                                    <tr>
                                        <th colspan="4" style="background-color: #4066d7!important;">
                                            <div style="display: flex; justify-content: center; align-items: center;">
                                                <img src="/logo.png" alt=""> <span style="font-size: 50px; font-weight: 700; color: #fff!important; margin-left: 15px;">NITOL CLASSIS</span>
                                            </div>
                                        </th>
                                    </tr>
                                    <tr>
                                        <th colspan="2" style="font-size: 20px;">Destination (Address)</th>
                                        <th colspan="2" style="font-size: 20px;">Booking Date </th>
                                    </tr>
                                    <tr>
                                        <th colspan="2" style="color: #d90b0b!important; font-size: 45px; border-bottom: 6px solid #4066d7!important;"> <?php echo $drop->name ?> </th>
                                        <th colspan="2" style="color: #d90b0b!important; font-size: 45px; border-bottom: 6px solid #4066d7!important;"><?php echo(!empty($ticket->create_date) ? date("d-F-Y",strtotime($ticket->create_date)) : null) ?></th>
                                    </tr>
                                    <tr>
                                        <th colspan="2" style="font-size: 20px;">Sender Details</th>
                                        <th colspan="2" style="font-size: 20px;"> Receiver Details</th>
                                    </tr>
                                    <tr>
                                        <th colspan="2">
                                            <p style="font-size: 16px;">Name(s) & Surename</p>
                                            <h3 style="color: #d90b0b!important; font-size: 40px; font-weight: 600; margin-top: 5px;"><?php echo(!empty($sender->passenger_name) ? $sender->passenger_name : null) ?></h3>
                                        </th>
                                        <th colspan="2">
                                            <p style="font-size: 16px;">Name(s) & Surename</p>
                                            <h3 style="color: #d90b0b!important; font-size: 40px; font-weight: 600; margin-top: 5px;"><?php echo(!empty($receiver->passenger_name) ? $receiver->passenger_name : null) ?></h3>
                                        </th>
                                    </tr>
                                    <tr>
                                        <th colspan="2" style="border-bottom: 6px solid #4066d7!important;">
                                            <p style="font-size: 16px;">Cell Number</p>
                                            <h3 style="color: #d90b0b!important; font-size: 40px; font-weight: 600; margin-top: 5px;"><?php echo(!empty($sender->phone) ? $sender->phone : null) ?></h3>
                                        </th>
                                        <th colspan="2" style="border-bottom: 6px solid #4066d7!important;">
                                            <p style="font-size: 16px;">Cell Number</p>
                                            <h3 style="color: #d90b0b!important; font-size: 40px; font-weight: 600; margin-top: 5px;"><?php echo(!empty($receiver->phone) ? $receiver->phone : null) ?></h3>
                                        </th>
                                    </tr>
                                    <tr>
                                        <th colspan="2" style="width: 50%; font-size: 17px;">Booking id</th>
                                        <th style="font-size: 17px;">Number Of Items</th>
                                        <th style="font-size: 17px;">Payment Status</th>
                                    </tr>
                                    <tr>
                                        <th colspan="2" style="width: 50%; color: #d90b0b!important; font-size: 40px;"><?php echo $ticket->id_no; ?></th>
                                        <th style="color: #d90b0b!important; font-size: 40px;"><?php echo $print. ' Of ' . $numberofprint ?></th>
                                        <th>

                                        <?php $payment = $ticket->payment_status; ?>
                                        <?php if($payment == 1) : ?>  
                                            <div class="i-check">
                                                <input tabindex="9" type="checkbox" id="square-checkbox-3" checked>
                                                <label for="square-checkbox-3" style="font-size: 17px;">Unpaid</label>
                                            </div>
                                        <?php elseif($payment == 'Refunded') : ?>  

                                            <div class="i-check">
                                                <input tabindex="9" type="checkbox" id="square-checkbox-3" checked>
                                                <label for="square-checkbox-3" style="font-size: 17px;">Refunded</label>
                                            </div>

                                        <?php elseif($payment == 'partial') : ?>  
                                            <div class="i-check">
                                                <input tabindex="10" type="checkbox" id="square-checkbox-2" checked>
                                                <label for="square-checkbox-2" style="font-size: 17px;">Partial</label>
                                            </div>

                                            <?php else : ?>  
                                            <div class="i-check">
                                                <input tabindex="9" type="checkbox" id="square-checkbox-1" checked>
                                                <label for="square-checkbox-1" style="font-size: 17px;">Paid</label>
                                            </div>

                                        <?php endif ?> 
                                            
                                        </th>
                                    </tr>
                                </table>


               
                                
                                </div>


        <?php } ?>

           



    

    <script src="<?php echo base_url('assets/js/jquery-1.12.4.min.js')?>"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="<?php echo base_url('assets/js/bootstrap.min.js')?>"></script>
    <script src="<?php echo base_url('assets/js/script.min.js')?>"></script>
    <script type="text/javascript">
 

    </script>
</body>

</html>
