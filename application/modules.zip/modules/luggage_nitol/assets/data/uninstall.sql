DELETE FROM `language` WHERE `language`.`phrase` = 'luggage';
DELETE FROM `language` WHERE `language`.`phrase` = 'luggage_info';
DELETE FROM `language` WHERE `language`.`phrase` = 'add_luggage';
DELETE FROM `language` WHERE `language`.`phrase` = 'luggage_list';
DELETE FROM `language` WHERE `language`.`phrase` = 'unpaid_cash_luggage_list';
DELETE FROM `language` WHERE `language`.`phrase` = 'luggage_confirmation';
