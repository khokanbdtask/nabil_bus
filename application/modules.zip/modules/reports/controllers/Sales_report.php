<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sales_report extends MX_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->db->query('SET SESSION sql_mode = ""');
		$this->load->model(array(
			'sales_model'
		));		 
	}

    public function report()
	{   
        $this->permission->method('reports','read')->redirect();
		$data['title']    = display('reports');  
        #-------------------------------#
        $config["base_url"]   = base_url('reports/sales_report/report');
        $config['suffix'] = '?'.http_build_query($_GET, '', "&"); 
        $config['first_url'] = $config['base_url'].$config['suffix'];
        $config["per_page"] = 10;
        $config["uri_segment"] = 4;
       
        $page = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
        #-------------------------------#
        $start_date = $this->input->get('start_date');
        $end_date   = $this->input->get('end_date');
        $trip_id = $this->input->get('trip');
        $route_id = $this->input->get('route');

        $data['search'] = (object)array(
            'limit'  => $config["per_page"],
            'offset' => $page,
            'filter'     => trim($this->input->get('filter')),
            'trip'       => trim($this->input->get('trip')),
            'route'      => trim($this->input->get('route')),
            'start_date' => (!empty($start_date)?trim($start_date):date('d-m-Y')),
            'end_date'   => (!empty($end_date)?trim($end_date):date('d-m-Y')),
        );

        $trip_name = $this->db->select('trip.trip_title')
                    ->from('trip_assign')
                    ->join('trip','trip_assign.trip = trip.trip_id','left')
                    ->where('trip_assign.id', $trip_id) 
                    ->get()
                    ->row();
        $route_name = $this->db->select('*')->from('trip_route')->where('id',$route_id)->get()->row();

        #-------------------------------#
        #
        #pagination starts
        #
        // $config["total_rows"] = $this->sales_model->countRecord($data['search']);
        // $config["last_link"] = "Last"; 
        // $config["first_link"] = "First"; 
        // $config['next_link'] = 'Next';
        // $config['prev_link'] = 'Prev';  
        // $config['full_tag_open'] = "<ul class='pagination col-xs pull-right'>";
        // $config['full_tag_close'] = "</ul>";
        // $config['num_tag_open'] = '<li>';
        // $config['num_tag_close'] = '</li>';
        // $config['cur_tag_open'] = "<li class='disabled'><li class='active'><a href='#'>";
        // $config['cur_tag_close'] = "<span class='sr-only'></span></a></li>";
        // $config['next_tag_open'] = "<li>";
        // $config['next_tag_close'] = "</li>";
        // $config['prev_tag_open'] = "<li>";
        // $config['prev_tagl_close'] = "</li>";
        // $config['first_tag_open'] = "<li>";
        // $config['first_tagl_close'] = "</li>";
        // $config['last_tag_open'] = "<li>";
        // $config['last_tagl_close'] = "</li>";
        // /* ends of bootstrap */
        // $this->pagination->initialize($config);
        $data["bookings"] = $this->sales_model->read($data['search']);
        $data["links"] = $this->pagination->create_links();
        #
        #pagination ends
        #
        $data['routeList']  = $this->sales_model->routeList();
        $data['trip_name'] = (!empty($trip_name))?$trip_name->trip_title:'';
        $data['route_name'] = (!empty($route_name))?$route_name->name:'';
        $data['tripList']   = $this->sales_model->tripList();
        $data['company']    = $this->sales_model->company_info();
        $data['appSetting'] = $this->sales_model->website_setting();
        // $data['currency']   = $currency;
		$data['module'] = "reports";
		$data['page']   = "booking/sale_booking";   
		echo Modules::run('template/layout', $data); 
	}  
}