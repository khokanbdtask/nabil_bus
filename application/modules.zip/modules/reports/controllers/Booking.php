<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Booking extends MX_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->db->query('SET SESSION sql_mode = ""');
		$this->load->model(array(
            'booking_model','price/price_model' 
		));		 
	}
 
	public function report()
	{   
        $this->permission->method('reports','read')->redirect();
        $data['title']    = display('reports');  
        #-------------------------------#
        $config["base_url"]   = base_url('reports/booking/report');
        $config['suffix'] = '?'.http_build_query($_GET, '', "&"); 
        $config['first_url'] = $config['base_url'].$config['suffix'];
        $config["per_page"] = 10;
        $config["uri_segment"] = 4;
         $currency_details = $this->price_model->retrieve_setting_editdata();
        foreach ($currency_details as $price) {
        }
        $currency=$price['currency'];
        $page = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
        #-------------------------------#
        $start_date = $this->input->get('start_date');
        $end_date   = $this->input->get('end_date');
          #----------new code 2021 for single day report------------#
         
          
        // can be line remove
        $single_day   = $this->input->get('single_day');
          #----------new code 2021 for single day report------------#
      
         $data['single_day'] =  (!empty($single_day)?trim($single_day):date('d-m-Y'));
        #----------new code 2021 for single day report------------#

        $data['search'] = (object)array(
            'limit'  => $config["per_page"],
            'offset' => $page,
            'filter'     => trim($this->input->get('filter')),
            'trip'       => trim($this->input->get('trip')),
            'route'      => trim($this->input->get('route')),
            'driver'     => trim($this->input->get('driver')),
            'start_date' => (!empty($start_date)?trim($start_date):date('d-m-Y')),
            'end_date'   => (!empty($end_date)?trim($end_date):date('d-m-Y')),
              #----------new code 2021 for single day report------------#
            'single_day'   => (!empty($single_day)?trim($single_day):date('d-m-Y')),
              #----------new code 2021 for single day report------------#
        );

        
        #-------------------------------#
        #
        #pagination starts
        #
        $config["total_rows"] = $this->booking_model->countRecord($data['search']);
        $config["last_link"] = "Last"; 
        $config["first_link"] = "First"; 
        $config['next_link'] = 'Next';
        $config['prev_link'] = 'Prev';  
        $config['full_tag_open'] = "<ul class='pagination col-xs pull-right'>";
        $config['full_tag_close'] = "</ul>";
        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';
        $config['cur_tag_open'] = "<li class='disabled'><li class='active'><a href='#'>";
        $config['cur_tag_close'] = "<span class='sr-only'></span></a></li>";
        $config['next_tag_open'] = "<li>";
        $config['next_tag_close'] = "</li>";
        $config['prev_tag_open'] = "<li>";
        $config['prev_tagl_close'] = "</li>";
        $config['first_tag_open'] = "<li>";
        $config['first_tagl_close'] = "</li>";
        $config['last_tag_open'] = "<li>";
        $config['last_tagl_close'] = "</li>";
        /* ends of bootstrap */
        $this->pagination->initialize($config);
        $data["bookings"] = $this->booking_model->read($data['search']);
        $data["links"] = $this->pagination->create_links();
        #
        #pagination ends
        #   
        $data["logo"] = $this->db->select("*")
        ->from('setting')
        ->get()
        ->row();
        $data['routeList']  = $this->booking_model->routeList();
        $data['tripList']   = $this->booking_model->tripList();
        $data['driverList'] = $this->booking_model->driverList();
         $data['currency']   = $currency;
		$data['module'] = "reports";
		$data['page']   = "booking/list";   
		echo Modules::run('template/layout', $data); 
	}
    
    
    # new code 2021 show single day basis report

    public function singleDayReport($start_date,$end_date)
    {
   

      $start_date = $start_date;
      $end_date   = $end_date;

        $this->permission->method('reports','read')->redirect();
		    $data['title']    = display('reports');  
        #-------------------------------#
        $config["base_url"]   = base_url('reports/booking/report');
        $config['suffix'] = '?'.http_build_query($_GET, '', "&"); 
        $config['first_url'] = $config['base_url'].$config['suffix'];
        $config["per_page"] = 10;
        $config["uri_segment"] = 4;
         $currency_details = $this->price_model->retrieve_setting_editdata();
        foreach ($currency_details as $price) {
        }
        $currency=$price['currency'];
        $page = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
        #-------------------------------#

         
        $single_day   = $this->input->get('single_day');
       
      
         $data['single_day'] =  (!empty($single_day)?trim($single_day):date('d-m-Y'));
        

        $data['search'] = (object)array(
            'limit'  => $config["per_page"],
            'offset' => $page,


            'filter'     => trim($this->input->get('filter')),
            'trip'       => trim($this->input->get('trip')),
            'route'      => trim($this->input->get('route')),
            'driver'     => trim($this->input->get('driver')),
            
            'start_date' => (!empty($start_date)?trim($start_date):date('d-m-Y')),
            'end_date'   => (!empty($end_date)?trim($end_date):date('d-m-Y')),
            'single_day'   => (!empty($single_day)?trim($single_day):date('d-m-Y')),
             
        );


        
        #-------------------------------#
        #
        #pagination starts
        #
        $config["total_rows"] = $this->booking_model->countRowSingleDay($data['search']);
        $config["last_link"] = "Last"; 
        $config["first_link"] = "First"; 
        $config['next_link'] = 'Next';
        $config['prev_link'] = 'Prev';  
        $config['full_tag_open'] = "<ul class='pagination col-xs pull-right'>";
        $config['full_tag_close'] = "</ul>";
        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';
        $config['cur_tag_open'] = "<li class='disabled'><li class='active'><a href='#'>";
        $config['cur_tag_close'] = "<span class='sr-only'></span></a></li>";
        $config['next_tag_open'] = "<li>";
        $config['next_tag_close'] = "</li>";
        $config['prev_tag_open'] = "<li>";
        $config['prev_tagl_close'] = "</li>";
        $config['first_tag_open'] = "<li>";
        $config['first_tagl_close'] = "</li>";
        $config['last_tag_open'] = "<li>";
        $config['last_tagl_close'] = "</li>";
        /* ends of bootstrap */
        $this->pagination->initialize($config);
        $data["bookings"] = $this->booking_model->readSingleDayRecord($data['search']);

        // var_dump( $data["bookings"]);

        // exit;

        $data["links"] = $this->pagination->create_links();
        #
        #pagination ends
        #   
        $data['routeList']  = $this->booking_model->routeList();
        $data['tripList']   = $this->booking_model->tripList();
        $data['driverList'] = $this->booking_model->driverList();
         $data['currency']   = $currency;
		$data['module'] = "reports";
		$data['page']   = "booking/list";   
		echo Modules::run('template/layout', $data); 

    }


    # new code 2021 show single day basis report
}
