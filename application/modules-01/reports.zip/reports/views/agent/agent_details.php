<div class="row">
    <div class="col-sm-12">
        <div class="panel panel-bd">
            <div class="panel-heading">
                <div class="panel-title">
                    <h4> 
                       <?php echo display('agent_report') ?>  <a href="#" class="btn btn-sm btn-danger" title="Print" onclick="printContent('PrintMe')"><i class="fa fa-print"></i></a>  
                    </h4>
                </div>
            </div>
            <div class="panel-body">
                 <div class="col-sm-12" style="margin-bottom:20px">
                    <?php echo form_open('reports/agent/agent_details', 'class="form-horizontal" method="post"')?>
                     <div class="form-group" id="agnt">
                            <label for="agent_id" class="col-sm-2 control-label"><?php echo display('select_agent_name') ?></label>
                            <div class="col-sm-10">
                                 <?php echo form_dropdown('agent_id', $agent_list,$agen_id, "class='form-control' id='agent_id' style='width:100%'") ?>
                            </div>
                        </div>

                        <!-- Date 2 Date -->
                        <div class="form-group">
                            <label for="agent_id" class="col-sm-2 control-label"><?php echo display('date') ?></label>
                            <div class="col-sm-10">
                                <div class="row">
                                    <div class="col-sm-4">
                                        <input name="start_date" id="start_date" type="text" placeholder="<?php echo display('start_date') ?>" class="form-control datepicker" value="<?php echo $start_date ?>">
                                    </div>
                                    
                                    <div class="col-sm-4">
                                        <input name="end_date" id="end_date" type="text" placeholder="<?php echo display('end_date') ?>" class="form-control datepicker" value="<?php echo $end_date ?>">
                                    </div>


                                </div>
                            </div>
                        </div>
                     <div class="form-group">
                         <div class="row">
                             <div class="col-sm-3">
                                 <label for="booking_type">Booking Type</label>
                             </div>
                             <div class="col-sm-3">
                                 <label for=""><?php echo display("ticket"); ?>
                                 </label>
                                 <input name="booking_type[]" id="ticket_booking" type="checkbox"  class="form-control " value="1">
                             </div>

                             <div class="col-sm-3">
                                 <label for=""><?php echo display("luggage"); ?>
                                 </label>
                                 <input name="booking_type[]" id="luggage_booking" type="checkbox"  class="form-control " value="2">
                             </div>
                             <div class="col-sm-3">
                                 <button type="submit"  class="form-control btn btn-success"><?php echo display('search') ?></button>
                             </div>
                         </div>
                     </div>
                    <?php echo form_close() ?>
                </div>

            </div>
        </div>
    </div>
    </div>

<div class="row">
    <div class="col-sm-12 col-md-12">
        <div class="panel panel-bd">
            
            <div class="panel-body" id="PrintMe">

                <div class="text-center">
                   <h2> <?php echo $detls->agent_first_name.' '.$detls->agent_second_name; ?></h2>
                   <h4><?php echo $detls->agent_company_name; ?></h4>
                   <h4><?php echo 'phone :'.''.$detls->agent_phone; ?></h4>

                    <br>
                </div>
                <table width="100%"  id="StatusTable" class="sdatatable table table-striped table-bordered table-hover">
                    <thead>
            <tr>
                <th class="text-center"><?php echo display('serial') ?></th>
                <th class="text-center"><?php echo display('created_date') ?></th>
                <th class="text-center"><?php echo display('booking_date') ?></th>
                <th class="text-center"><?php echo display('booking_id') ?></th>
                <th class="text-center"><?php echo display('total_price') ?></th>
                <th class="text-center"><?php echo display('commission_amount') ?></th>
                <th class="text-center"><?php echo display('commission_rate') ?> (%)</th>
            </tr>
                    </thead>
                    <tbody>
                        <?php
                        $total_ticket = 0;
                        $total_price = 0;
                        $total_commission = 0;
                        if (!empty($agen)) {

                            ?>
                            <?php
                                $sl = 1;
                             ?>
                            <?php
                            $total_commission = 0;
                            $total_price = 0;
                            $total_ticket = count($agen);
                             foreach ($agen as $query) {
                                if($query->tkt_refund_id !=''){
                               $total_price += 0;
                                $total_commission += 0*$query->commission_rate/100;     
                            }else{
                                $total_price += $query->total_price;
                                $total_commission += $query->total_price*$query->commission_rate/100;
                            }
                                

                                $booking_type = str_split($query->booking_id);

                                if($booking_type[0]=="L")
                                {
                                    $b_type = "luggage";
                                }
                                else
                                {
                                    $b_type = "ticket";
                                }
                              ?>
                                <tr style="background-color:<?php echo ($query->tkt_refund_id !=''?'#F2D7D5':'')?>;">
                                <td><?php echo $sl; ?></td>
                                <td><?php echo $query->create_date; ?></td>
                                <td><?php echo $query->date; ?></td>
                                <td>

                                    <a href="<?php echo ($b_type == "ticket")?base_url("ticket/booking/view/$query->booking_id"):base_url("luggage_nitol/luggage/view/$query->booking_id") ?>">
                                        <?php echo $query->booking_id; ?>
                                    </a>
                                </td>
                                <td class="text-right"><?php    if($query->tkt_refund_id !=''){echo 'Refunded';}else{
                               echo $currency.' '.$query->total_price;
                                } ?></td>
                                <td class="text-right">

                                <?php
                                 if($query->tkt_refund_id !=''){echo 'Refunded';}else{
                                  echo $currency.' '.$query->total_price*$query->commission_rate/100;} ?></td>
                                <td class="text-right"><?php if($query->tkt_refund_id !=''){echo 0;}else{ echo $query->commission_rate;} ?></td>
                                </tr>
                                <?php $sl++; ?>
                            <?php } ?> 
                        <?php } ?> 
                    </tbody>
                    <tfooter>
                        <tr><td colspan="2" class="text-right"><b>Total </b></td><td><?php echo $total_ticket;?></td><td class="text-right"><b><?php echo $currency; ?> <?php echo $total_price;?></b></td><td class="text-right"><b><?php echo $currency; ?> <?php echo $total_commission;?></b></td><td></td></tr>
                    </tfooter>
                </table>  <!-- /.table-responsive -->
            </div> 
        </div>
    </div>
</div>

<script type="text/javascript">
    $(function($){
    "use strict";
    //tooltips
    $('[data-toggle="tooltip"]').tooltip();
    //datatable
    $('.sdatatable').DataTable({ 
        responsive: true, 
        dom: "<'row'<'col-sm-4'l><'col-sm-4 text-center'B><'col-sm-4'f>>tp", 
        "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]], 
        buttons: [  
            {extend: 'copy', className: 'btn-sm prints'}, 
            {extend: 'csv', title: 'AgentLog', className: 'btn-sm prints'}, 
            {extend: 'excel', title: 'AgentLog', className: 'btn-sm prints'}, 
            {extend: 'pdf', title: 'AgentLog', className: 'btn-sm prints'}, 
            {extend: 'print', className: 'btn-sm prints'} 
        ] 
    });
     });
</script>
