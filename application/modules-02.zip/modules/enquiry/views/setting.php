<div class="row">
    <div class="col-sm-12 col-md-12">
        <div class="panel panel-bd lobidrag">
            <div class="panel-heading">
                <div class="panel-title">
                    <h4>
                        <a href="<?php echo base_url('enquiry/home/index') ?>" class="btn btn-sm btn-success" title="Enquiry List"><i class="fa fa-list"></i> <?php echo display('list') ?></a>  
                    </h4>
                </div>
            </div>
            <div class="panel-body">

      <div class="col-sm-12">
          <div class="col-sm-6">
          <div class="panel panel-default">
            <div class="panel-heading">Html Code Sample <code class="text-primary">Place this code wherever you want the plugin to appear on your page.</code></div>
            <div class="panel-body">
            <textarea spellcheck="false" class="form-control" rows="14">&lt;iframe id="sframe" src="<?php echo base_url("enquiry/home/iframe") ?>" 
width="100%" 
height="600px" 
marginwidth="0"
marginheight="0" 
frameborder="0" 
scrolling="no" &gt;&lt;/iframe&gt;  
            </textarea>
            </div>
          </div>
          </div>

          <div class="col-sm-6">
          <div class="panel panel-default">
            <div class="panel-heading">Js Code Sample <code class="text-primary">Place this code wherever you want the plugin to appear on your page.</code></div>
            <div class="panel-body">
            <textarea spellcheck="false" class="form-control" rows="14">&lt;script type="text/javascript"&gt; 
var sfrm = document.createElement('iframe');
sfrm.setAttribute('id', 'iframe'); 
sfrm.setAttribute('src', '<?php echo base_url("enquiry/home/iframe") ?>'); 
sfrm.setAttribute('width', '100%');
sfrm.setAttribute('height', '600px');
sfrm.setAttribute('frameborder', '0');
sfrm.setAttribute('scrolling', 'no');
document.write('&lt;div id="s384gh4r"&gt;&lt;/div&gt;');
document.getElementById('s384gh4r').appendChild(sfrm);
&lt;/script&gt;
            </textarea>
            </div>
          </div>
          </div>

        </div>

            </div>  
        </div>
    </div>
</div>
 