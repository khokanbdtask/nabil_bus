INSERT INTO `language` (`phrase`, `english`, `french`) VALUES
('tracking_list', 'Tracking List', NULL),
('progress', 'Trip Progress (%)', NULL),
('reached_points', 'Current Position', NULL),
('arrival_time', 'Arrival Time', 'Arrival Time'),
('tracking_route_id', 'Route', NULL),
('tracking_date', 'Tracking Date', NULL),
('tracking_fleet_id', 'Fleet ', NULL),
('delete_tracking', 'Delete Tracking', NULL),
('edit_tracking', 'Edit Tracking', NULL),
('tracking', 'Tracking', NULL),
('add_tracking', 'Add Tracking', NULL);