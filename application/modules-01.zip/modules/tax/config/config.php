<?php
// module directory name
$HmvcConfig['tax']["_title"]     = "Tax Details ";
$HmvcConfig['tax']["_description"] = "Simple tax processing System";
	  
$HmvcConfig['tax']['_database'] = true;
$HmvcConfig['tax']["_tables"] = array( 
	'tax',
);
