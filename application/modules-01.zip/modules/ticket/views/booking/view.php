<div class="row">
    <div class="col-sm-12 col-md-12">
        <div class="panel panel-bd lobidrag">
            <div class="panel-heading">
                <div class="panel-title">
                    
                </div>
            </div>

            <div class="panel-body" id="PrintMe">
                <table class="table table-hover" width="100%">
                    <thead>
                    <tr>
                        <th>Payment Type</th>
                        <td><?php echo $paytype; ?></td>
                    </tr>
                    <tr>
                        <th>Payment Detail</th>
                        <td><?php echo $paydetail; ?></td>
                    </tr>
                   
                    </thead>
                </table>
            </div>
        </div>
    </div>
</div> 





